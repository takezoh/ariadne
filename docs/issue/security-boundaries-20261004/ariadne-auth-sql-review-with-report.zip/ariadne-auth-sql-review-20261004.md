# Ariadne 認証・SQLレビュー報告書

**作成日：2026年10月4日（JST）**  
**対象リポジトリ：`takezoh/ariadne`（旧名称：Awhen）**  
**対象コミット：`f8142c6490314fc3723d97bac62a1323d6aa7570`**  
**報告の状態：指摘・修正提案。アプリケーションの修正、デプロイ、本番DB操作は未実施。**

## 1. 結論

確認した実装では、認証ユーザーのIDを `owner` とし、D1の読み取り・書き込み・操作履歴をowner単位に分離している。確認したSQL経路に、owner条件の欠落による他ユーザーのデータへのアクセスや、利用者の値をSQL構文として挿入する経路は見つからなかった。ただし、これは対象コミットと確認範囲についての評価であり、本番環境全体の安全性を保証するものではない。[S1][S4][S5]

修正を推奨する指摘は次の2件。

| ID | 指摘 | 重要度 | 確認状況 |
| --- | --- | --- | --- |
| AUTH-01 | `/mcp` にOriginとContent-Typeの入口検査がない | 中・本番影響は条件付き | コード上の欠落を確認。JSONパーサーの挙動をローカル再現。本番での攻撃成立は未確認 |
| SQL-01 | 小さな操作でも、生成された操作履歴がD1の文字列・行サイズ上限を超える | 中・可用性 | 実装のSQLと履歴形式を用いた分離再現でサイズ超過・保存失敗を確認。実D1・サービス全体の実行ではない |

**ユーザー分離を一から追加する必要がある実装ではない。優先する修正は、MCP入口の検査の統一と、生成される保存データのサイズ制御である。**

## 2. 対象と検証範囲

本書は、前回のレビュー回答と添付証跡を報告書として整理したもの。作成にあたり、同じ対象コミットの認証、MCPルート、Web APIルート、D1アダプター、アプリケーションサービスの関連箇所を再取得し、添付済みの分離再現スクリプトも再実行した。

| 対象 | 内容・制約 |
| --- | --- |
| 認証 | `requireOwner()`、MCP/Web APIからの呼び出し、ownerの受け渡し |
| SQL | D1アダプターの読み取り、削除、UPSERT、操作履歴、revision競合の処理 |
| 入力・保存サイズ | 入力のUTF-8バイト制限と、生成される履歴・JSONバインド値 |
| ローカル認証検証 | 対象の認証ソースをGit blob SHAで照合して実行。依存する `fail` は検証用に再実装 |
| ローカルSQL検証 | 実装のSQL形状とrevisionトリガーを用い、必要な列・キーを持つ検証用スキーマをSQLite上に作成 |
| 再実行結果 | 認証6項目、SQL14項目。両JSON結果は前回の添付結果と一致 |
| 今回行っていないこと | リポジトリ全体のテスト、サービス全体を通した再現、実アカウント2つでの本番検証、実D1への負荷・境界値試験、稼働版・デプロイ設定の確認 |

再現結果の `pass: true` は、その検証が意図した現象を確認したことを表す。**不適切なContent-TypeのJSONが解析されることや、保存がサイズ超過で失敗することも「確認成功」に含まれる。「全項目pass＝不具合なし」ではない。**

## 3. AUTH-01：MCP入口のOrigin・Content-Type検査がない

### 3.1 根拠

`app/mcp/route.ts` の `POST()` は、`req.json()` で本文を読み、`tools/call` では `requireOwner(req.headers)` の結果を `actionCall()` に渡している。一方、このルートにはOriginとContent-Typeの検査がない。[S2]

`app/api/actions/route.ts` には、Originが指定されていて要求URLのOriginと異なる場合の403応答と、Content-Typeに `application/json` が含まれない場合の415応答がある。[S3]

| 検査 | `/api/actions` | `/mcp` の `tools/call` |
| --- | --- | --- |
| 認証identityの確認 | あり | あり |
| 不正なOriginの拒否 | あり | なし |
| JSONのContent-Type確認 | あり | なし |

MCP Streamable HTTPの2025-11-25仕様は、Originの検証を要求し、Originが指定されていて不正な場合はHTTP 403を返すよう定めている。本書では、アプリのMCPルートにその検査がないことを指摘している。上流が同等の検査を行っているかは未確認。[P1]

### 3.2 ローカルで確認した現象

`reproduce_auth.cjs` で、架空の異なるOriginと `Content-Type: text/plain` を持つRequestを作り、JSON本文を `Request.json()` に渡した。その結果、本文はJSONとして解析された。

```text
Origin: https://other.example.test
Content-Type: text/plain

本文のmethod: tools/call
Request.json()の結果: 解析成功
```

これは標準RequestのJSON解析挙動の確認である。**このスクリプトはAriadneのMCPルート全体を実行せず、タスクを変更しておらず、本番でのCSRF成立を実証していない。**

### 3.3 影響と成立条件

懸念は、異なるサイトから送られた要求が、上流の認証処理を経て本人の操作として到達した場合に、アプリ自身の入口検査では拒否できないことにある。実際の変更成立には、要求がSites側を通ること、認証情報の付与条件、ブラウザーのCookie送信条件、正しい操作引数とrevisionなどが関係する。

これらの条件は今回確認していないため、「第三者が本番タスクを変更できる」「認証を迂回できる」とは判定しない。

### 3.4 修正提案

`/mcp` と `/api/actions` の入口検査を共通化する。Originが指定されている場合は、信頼できる設定から定めた許可Originだけを通す。Content-Typeはメディアタイプとして解析し、`application/json` を確認する。`application/json; charset=utf-8` のような正当なパラメーター付き指定は許可する設計がよい。

既存Web APIの検査は部分文字列の `includes("application/json")` であるため、そのまま複製するより、共通処理でメディアタイプを正規化して比較することを推奨する。[S3]

Origin検査は認証の代替ではない。また、Originを送らない正当なサーバー間MCP呼び出しを壊さないよう、**Originなしを一律拒否する修正にはしない**。どの経路を許可するかは実際の呼び出し・認証契約に合わせる。

### 3.5 修正後の受け入れ条件案

| ケース | 期待結果 |
| --- | --- |
| 許可外Origin | 403。サービス・保存処理を実行しない |
| JSON本文だが `text/plain` | 415。サービス・保存処理を実行しない |
| 許可Origin、正しい認証、正しいJSON | 通常どおり処理 |
| Originなしの正規サーバー間要求 | 認証・許可経路の条件を満たす場合に処理 |
| identityの欠落 | 未認証として拒否 |

## 4. SQL-01：生成履歴がD1の2MB上限を超える

### 4.1 根拠

`lib/application/action-service.ts` は、操作の元入力をcanonical JSONにした値について、UTF-8で262,144バイトを超えた場合に `operation_too_large` とする。[S5]

一方、`lib/adapters/d1-action-store.ts` の `commit()` は、変更前後から生成された差分全体を `JSON.stringify(changes)` とし、`operations.delta` の1つの値として保存する。この保存処理には、生成されたdelta、結果、保存行全体のサイズ検査がない。行更新でも変更行をまとめたJSONを `json_each(?)` に渡す。[S4]

Cloudflare D1の公表値では、文字列・BLOB・テーブル行の最大サイズは2,000,000バイト。入力の上限だけを検査しても、保存時に展開・集約された値の上限は保証できない。[P2]

### 4.2 分離再現の条件

検証用データとして、親Actionを1件、子Actionを6件作成する。各子のメモは「あ」を65,536文字とし、それぞれの追加操作を個別に保存する。その後、親と子のステータスが完了になる場合の、変更前後の行全体を含む差分を生成する。

この再現はアプリのサービスを呼び出すものではなく、対象実装の保存SQL・履歴形式をモデル化したものである。子孫も完了する仕様は対象コミットのMCP操作定義にも記載されている。[S2]

| 測定項目 | 結果 |
| --- | ---: |
| 個々の追加要求の最大サイズ | 196,837バイト |
| 現行の元入力の上限 | 262,144バイト |
| 親を完了する要求のサイズ | 198バイト |
| 生成した変更前後の履歴JSON | 2,363,848バイト |
| SQLiteに設定した文字列・行サイズ上限 | 2,000,000バイト |
| 履歴INSERT | `string or blob too big` で失敗 |
| 失敗後にactiveのまま残るAction | 7件 |
| 失敗した完了操作の新規receipt | なし |

数値は添付の再現データ・日時・属性構成での測定値であり、任意のデータで同じバイト数になるという意味ではない。ここで示す問題は、**198バイトの要求でも、生成される保存値が約2.36MBになり得る**ことである。

### 4.3 影響とトランザクションに関する留保

大きなメモを持つ複数Actionの一括操作が、入力としては許可されても保存時に失敗する。現行のMCP/Web APIでは、既知のアプリケーションエラー以外のDB例外は `outcome_unknown` にまとめられるため、同一入力で解消しないサイズ超過にも結果確認・再試行の案内が返る。[S2][S3][S4]

ローカル再現では、操作履歴のINSERTが最初に失敗し、後続のAction更新は実行されなかった。したがって、部分更新や新しいreceiptは残っていない。**この試験だけで、バッチの途中まで書いた場合の本番D1のロールバックを実測したとはいえない。**

コード上はreceiptと関連する行変更を同じ `db.batch()` に入れている。バッチ内の失敗で全体が中止・ロールバックされることは、D1の公式仕様に基づく。[S4][P3]

この指摘の直接の対象は可用性とエラー分類であり、他ユーザーのデータ漏えいやデータ破損を確認したという報告ではない。

### 4.4 修正提案

まず、DBへ渡す前に、生成されたdelta・結果・大きなJSONバインド値、および保存行全体のサイズを検査する。文字数ではなくUTF-8バイト数を基準とし、行内の他の値やエンコード上の余裕も含めた保守的な上限を置く。上限を超える場合は、DBに変更を送る前に `operation_too_large` を返す。

この検査はエラーを明確にする修正であり、大きな一括操作を可能にする修正ではない。必要な一括操作を維持するには、履歴を複数行へ分ける、変更属性だけを記録する、行更新用JSONを分割する、といった保存形式の見直しが必要になる。

保存形式を変える場合も、**タスク変更・操作履歴・revision更新の原子性、同一operationIdの冪等性、最新の変更を上書きしないUndo**を維持する。単純にバッチを別トランザクションへ分割する方法は、この性質を壊すため避ける。

### 4.5 修正後の受け入れ条件案

| ケース | 期待結果 |
| --- | --- |
| 本書の親1件＋子6件の再現 | 設計に応じて原子的に成功、または保存前に明確なサイズ超過エラー |
| 上限近傍のdelta・result・行全体 | 各値と行全体の制約を守る |
| 日本語・絵文字を含む長文 | 文字数ではなく実際のUTF-8バイト数で判定 |
| サイズ超過での拒否 | Action、receipt、revisionが変更されない |
| 同一ID・同一入力の再送 | 二重保存しない。確定済みreceiptを維持 |
| 履歴形式変更後のUndo | その後の訂正を上書きしない |

## 5. 認証・SQLで確認した防御

### 5.1 認証identityとowner

`requireOwner()` は `oai-authenticated-user-id` を返し、IDまたは `oai-authenticated-user-email` が欠ける場合に401のアプリケーションエラーを発生させる。emailの文字列ではなくIDがownerとなる。[S1]

MCP/Web APIはこのownerをサービスへ渡す。操作引数は許可フィールドを検査する構成で、確認した操作経路では利用者が引数でownerを置き換える仕組みはない。[S2][S3][S5]

ローカル検証では、identityなし、emailだけ、IDだけの3ケースが拒否されること、IDがownerになること、emailの変更だけではIDに対応するownerが切り替わらないことを確認した。

### 5.2 ownerスコープとSQLパラメーター

| 項目 | 確認した実装 |
| --- | --- |
| Action・Project・Tag・Perspective・関連表の読み取り | `WHERE owner=?` |
| 操作履歴の読み取り | `WHERE owner=? AND operation_id=?` |
| 行の削除 | owner条件と対象キーを組み合わせる |
| UPSERT | `ON CONFLICT(owner, ...)` を使用 |
| Undo済み判定 | owner条件と `undo_of` を組み合わせる |
| 古い操作履歴の削除 | owner条件とrevisionの範囲を組み合わせる |
| 値の入力 | `.bind()` で渡す |
| 動的なテーブル名・列名 | アダプター内の固定定義から渡し、利用者の入力を使用しない |

上記はD1アダプターの実装に基づく。[S4] 検証用SQLiteでは、同じAction IDを持つ2つのownerの分離、UPSERT・DELETEの分離、ownerやtitle・notesにSQL構文風の文字列を渡しても値として扱われること、owner別のrevision進行、古いrevisionの拒否を確認した。

ただし、分離再現は本番スキーマの全制約や全SQL経路を網羅する試験ではない。実アカウント間の認可が本番で成立することは、上流のidentity保証を含めた別の確認事項である。

## 6. 本番環境で未確認の境界

この認証関数は、受け取ったidentityヘッダーを信頼する設計であり、独立した署名検証は行わない。[S1] この設計だけを不具合とは判定しないが、安全に成立するには次の境界が必要になる。

| 未確認事項 | 確認すべき内容 |
| --- | --- |
| identityヘッダーの保証 | 外部から渡された同名ヘッダーが認証境界で除去・置換されること |
| 認証経路の迂回 | 認証済み経路を通らず、任意のidentityヘッダーでWorkerへ到達できる公開経路がないこと |
| Origin・Cookieの挙動 | 許可外Originからの要求と認証情報が、実際の経路でどう処理されるか |
| 稼働版の一致 | 本番で動いているコードと設定が対象コミットの内容と一致すること |
| 実D1での境界値 | サイズ超過時のエラー形式、原子性、UI/MCPへの応答 |

本書はこれらを確認済みとは扱わない。また、対象コミット以後の変更をレビューした報告でもない。

## 7. 証跡と再実行方法

前回添付した `ariadne-auth-sql-review.zip` には、以下の5ファイルが含まれていた。報告書本文は含まれていなかったため、本書を追加した版を別途作成した。

| ファイル | 内容 |
| --- | --- |
| `README.md` | 分離検証の対象・制約・実行方法 |
| `reproduce_auth.cjs` | 認証ソースの照合と単体実行、RequestのJSON解析挙動 |
| `reproduce_sql.py` | owner分離、値バインド、revision、サイズ超過の分離再現 |
| `auth-results.json` | 認証関連6項目の確認結果 |
| `sql-results.json` | SQL関連14項目の確認結果 |

再実行には、Python 3.11以降（`sqlite3.setlimit` を使用）と、標準の `Request` / `Headers` を持つNode.js、`require('typescript')` で解決できるTypeScriptが必要。

```sh
python reproduce_sql.py
node reproduce_auth.cjs
```

スクリプトは自身と同じディレクトリの結果JSONを更新する。保存済み証跡をそのまま保全する場合は、コピーしたディレクトリで実行する。

報告書作成時の再実行では、認証6項目とSQL14項目のJSONがそれぞれ元の添付結果と一致した。本番サイトへの通信、実タスクの作成・変更、GitHubへの書き込みは行っていない。

## 8. ソース・仕様参照

コード参照はすべて対象コミットに固定している。

- [S1 認証ヘルパー：lib/server/auth.ts](https://github.com/takezoh/ariadne/blob/f8142c6490314fc3723d97bac62a1323d6aa7570/lib/server/auth.ts)
- [S2 MCPルート・操作定義：app/mcp/route.ts](https://github.com/takezoh/ariadne/blob/f8142c6490314fc3723d97bac62a1323d6aa7570/app/mcp/route.ts)
- [S3 Web APIルート：app/api/actions/route.ts](https://github.com/takezoh/ariadne/blob/f8142c6490314fc3723d97bac62a1323d6aa7570/app/api/actions/route.ts)
- [S4 D1アダプター：lib/adapters/d1-action-store.ts](https://github.com/takezoh/ariadne/blob/f8142c6490314fc3723d97bac62a1323d6aa7570/lib/adapters/d1-action-store.ts)
- [S5 アプリケーションサービス：lib/application/action-service.ts](https://github.com/takezoh/ariadne/blob/f8142c6490314fc3723d97bac62a1323d6aa7570/lib/application/action-service.ts)
- [P1 MCP 2025-11-25：Streamable HTTP / Security Warning](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports#security-warning)
- [P2 Cloudflare D1：Limits](https://developers.cloudflare.com/d1/platform/limits/)
- [P3 Cloudflare D1：D1 Database / batch()](https://developers.cloudflare.com/d1/worker-api/d1-database/#batch)

仕様の参照日は2026年10月4日。コードのGitHubリンクには、当該リポジトリへのアクセス権が必要になる場合がある。
