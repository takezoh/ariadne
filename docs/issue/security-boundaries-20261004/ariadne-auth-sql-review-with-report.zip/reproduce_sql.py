"""Isolated SQL reproduction for Ariadne main f8142c6.
Uses SQL statement shapes from lib/adapters/d1-action-store.ts and the exact
0012 revision trigger, with synthetic data. This is NOT a hosted D1 test or
execution of Ariadne's full test suite.
"""
import copy
import json
import sqlite3
import uuid
from pathlib import Path

LIMIT = 2_000_000
NOW = '2026-10-04T02:00:00.000Z'
LATER = '2026-10-04T02:01:00.000Z'
results = []
def check(name, condition, **details):
    assert condition, name
    results.append({'test': name, 'pass': True, **details})
def js(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))

db = sqlite3.connect(':memory:')
db.executescript('''
CREATE TABLE actions (
 owner TEXT NOT NULL,id TEXT NOT NULL,title TEXT NOT NULL,
 revision INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
 parent_id TEXT,status TEXT NOT NULL DEFAULT 'active',due_at TEXT,defer_until TEXT,
 notes TEXT NOT NULL DEFAULT '',project_id TEXT,"order" INTEGER NOT NULL DEFAULT 0,
 flagged INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(owner,id));
CREATE TABLE operations (
 owner TEXT NOT NULL,operation_id TEXT NOT NULL,canonical_payload TEXT NOT NULL,
 result TEXT NOT NULL,delta TEXT NOT NULL,revision_before INTEGER NOT NULL,
 revision_after INTEGER NOT NULL,undo_of TEXT,created_at TEXT NOT NULL,
 PRIMARY KEY(owner,operation_id));
CREATE UNIQUE INDEX operations_owner_revision_uq ON operations(owner,revision_after);
CREATE TRIGGER operations_revision_guard BEFORE INSERT ON operations
BEGIN
 SELECT (CASE WHEN NEW.revision_before != COALESCE((SELECT MAX(revision_after) FROM operations WHERE owner = NEW.owner), 0)
  OR NEW.revision_after != NEW.revision_before + 1
 THEN RAISE(ABORT, 'revision_conflict') END);
END;
''')
cols=['id','title','revision','parent_id','project_id','status','due_at','defer_until','notes','order','flagged','created_at','updated_at']
values=','.join(f"json_extract(value,'$.{c}')" for c in cols)
updates=','.join(f'"{c}"=excluded."{c}"' for c in cols if c != 'id')
quoted=','.join(f'"{c}"' for c in cols)
upsert=f'INSERT INTO actions (owner,{quoted}) SELECT ?,{values} FROM json_each(?) WHERE 1 ON CONFLICT(owner,id) DO UPDATE SET {updates}'
delete="DELETE FROM actions WHERE owner=? AND EXISTS (SELECT 1 FROM json_each(?) WHERE actions.id=json_extract(value,'$.id'))"
receipt_insert='INSERT INTO operations(owner,operation_id,canonical_payload,result,delta,revision_before,revision_after,undo_of,created_at) VALUES(?,?,?,?,?,?,?,?,?)'
def action(title, notes='', parent=None, id_=None, order=0):
    return dict(id=id_ or str(uuid.uuid4()),title=title,revision=1,parent_id=parent,
        project_id=None,status='active',due_at=None,defer_until=None,notes=notes,
        order=order,flagged=False,created_at=NOW,updated_at=NOW)
def write_actions(owner, rows):
    db.execute(upsert,(owner,js(rows)))

a=action('A only')
b={**a,'title':'B only'}
write_actions('A',[a]); write_actions('B',[b]); db.commit()
check('same entity UUID stays owner-scoped', db.execute('SELECT title FROM actions WHERE owner=?',('A',)).fetchall()==[('A only',)])
write_actions('A',[{**a,'title':'A changed'}]); db.commit()
check('UPSERT conflict target includes owner',db.execute('SELECT title FROM actions WHERE owner=?',('B',)).fetchone()[0]=='B only')
db.execute(delete,('A',js([a])));db.commit()
check('DELETE includes owner even with identical entity UUID',db.execute('SELECT COUNT(*) FROM actions WHERE owner=?',('B',)).fetchone()[0]==1)
malicious_owner="B' OR 1=1 --"
check('owner injection string treated as data',db.execute('SELECT id FROM actions WHERE owner=?',(malicious_owner,)).fetchall()==[])
payload="'); DROP TABLE operations; --"
write_actions('A',[{**a,'title':payload,'notes':payload}]);db.commit()
check('title and notes injection strings remain literal',db.execute('SELECT title,notes FROM actions WHERE owner=?',('A',)).fetchone()==(payload,payload))
check('operations table survives injection text',db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='operations'").fetchone() is not None)
# Revision guard and rollback: a stale transaction must not leave changed rows.
for owner in ['A','B']:
    db.execute(receipt_insert,(owner,str(uuid.uuid4()),'{}','{}','{}',0,1,None,NOW))
db.commit()
check('revision independently advances per owner',db.execute('SELECT owner,MAX(revision_after) FROM operations GROUP BY owner ORDER BY owner').fetchall()==[('A',1),('B',1)])
try:
    with db:
        db.execute(receipt_insert,('A',str(uuid.uuid4()),'{}','{}','{}',0,1,None,NOW))
        write_actions('A',[{**a,'title':'stale changed'}])
except sqlite3.IntegrityError as e:
    check('stale revision aborts transaction', 'revision_conflict' in str(e))
else:
    raise AssertionError('stale revision unexpectedly accepted')
check('rejected write preserves prior action',db.execute('SELECT title FROM actions WHERE owner=?',('A',)).fetchone()[0]==payload)
# A legal sequence of individual additions creates six long-note child actions.
parent=action('Parent')
children=[action(f'Child {i}',notes='あ'*65536,parent=parent['id'],order=i) for i in range(6)]
before=[parent,*children]
max_single_request=max(len(js({'name':'apply_change','args':{'schemaVersion':2,'operationId':str(uuid.uuid4()),'expectedRevision':i,'kind':'add','payload':{'title':row['title'],'notes':row['notes'],'parent_id':row['parent_id']}}}).encode()) for i,row in enumerate(before))
check('each synthetic add is below current input limit',max_single_request < 262144,max_input_bytes=max_single_request)
db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH,LIMIT)
for i,row in enumerate(before):
    add_id=str(uuid.uuid4())
    add_payload=js({'name':'apply_change','args':{'schemaVersion':2,'operationId':add_id,'expectedRevision':i,'kind':'add','payload':{'title':row['title'],'notes':row['notes'],'parent_id':row['parent_id']}}})
    add_delta=js({'perspectives':[],'actions':[{'before':None,'after':row}],'projects':[],'tags':[],'action_tags':[]})
    add_result=js({'operationId':add_id,'revision':i+1,'changedIds':[row['id']],'resolved':{'actions':[{'id':row['id']}]}})
    with db:
        db.execute(receipt_insert,('large',add_id,add_payload,add_result,add_delta,i,i+1,None,NOW))
        write_actions('large',[row])
after=[{**row,'status':'completed','revision':2,'updated_at':LATER} for row in before]
# Same full before/after row delta shape as domain/operations.ts.
delta={'perspectives':[],'actions':[{'before':x,'after':y} for x,y in zip(before,after)],'projects':[],'tags':[],'action_tags':[]}
encoded_delta=js(delta)
request={'name':'apply_change','args':{'schemaVersion':2,'operationId':str(uuid.uuid4()),'expectedRevision':len(before),'kind':'complete','payload':{'id':parent['id']}}}
request_bytes=len(js(request).encode())
delta_bytes=len(encoded_delta.encode())
check('small completion input produces delta over D1 limit',request_bytes < 262144 and delta_bytes > LIMIT,input_bytes=request_bytes,delta_bytes=delta_bytes,d1_limit_bytes=LIMIT)
# SQLite can be configured to mirror the published D1 string/row length limit.
db.setlimit(sqlite3.SQLITE_LIMIT_LENGTH,LIMIT)
try:
    with db:
        db.execute(receipt_insert,('large',request['args']['operationId'],js(request),'{}',encoded_delta,len(before),len(before)+1,None,LATER))
        write_actions('large',after)
except sqlite3.DataError as e:
    check('receipt insertion fails at D1-equivalent length bound','too big' in str(e).lower(),error=str(e))
else:
    raise AssertionError('oversized delta unexpectedly accepted')
check('size rejection changes no task statuses',db.execute("SELECT COUNT(*) FROM actions WHERE owner='large' AND status='active'").fetchone()[0]==7)
check('size rejection leaves no new receipt',db.execute("SELECT COUNT(*) FROM operations WHERE owner='large'").fetchone()[0]==len(before))
report={'commit':'f8142c6490314fc3723d97bac62a1323d6aa7570','scope':'Isolated SQL reproduction; not hosted D1 and not the full repository test suite','tests':results}
Path(__file__).resolve().with_name('sql-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
