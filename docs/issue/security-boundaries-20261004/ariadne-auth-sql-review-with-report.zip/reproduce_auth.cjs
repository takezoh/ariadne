/** Isolated execution of the exact lib/server/auth.ts text at f8142c6.
 * The domain fail implementation is reproduced; no Site or real account is used.
 * Request.json checks demonstrate media-type parsing, not an end-to-end CSRF exploit.
 */
const assert = require('node:assert/strict');
const {createHash} = require('node:crypto');
const vm = require('node:vm');
const fs = require('node:fs');
const ts = require('typescript');
const source = "import {fail} from '../domain/core';\nexport function requireOwner(headers:Headers) {const owner=headers.get('oai-authenticated-user-id');if(!owner||!headers.get('oai-authenticated-user-email'))fail('unauthenticated','ChatGPTへの接続が必要です。',401);return owner;}\n\n";
const blobSha = createHash('sha1').update(`blob ${Buffer.byteLength(source)}\0`).update(source).digest('hex');
assert.equal(blobSha,'7ad06037d45e687b84459c1f36e27849ac6ff51a','source must match the fetched GitHub blob');
class ActionError extends Error { constructor(code,message,status=400){super(message);this.code=code;this.status=status;} }
function fail(code,message,status=400){throw new ActionError(code,message,status);}
const sandbox={exports:{},require(name){assert.equal(name,'../domain/core');return {fail};}};
vm.runInNewContext(ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS}}).outputText,sandbox);
const {requireOwner}=sandbox.exports;
const results=[];
function test(name,fn){fn();results.push({test:name,pass:true});}
for(const [label,fields] of [
  ['missing identity',{}],
  ['email without id',{'oai-authenticated-user-email':'a@example.test'}],
  ['id without email',{'oai-authenticated-user-id':'synthetic-A'}],
]) test(label+' is denied',()=>assert.throws(()=>requireOwner(new Headers(fields)),e=>e.code==='unauthenticated'&&e.status===401));
test('upstream id determines owner',()=>assert.equal(requireOwner(new Headers({'oai-authenticated-user-id':'synthetic-A','oai-authenticated-user-email':'a@example.test'})),'synthetic-A'));
test('different email does not switch the id-scoped owner',()=>assert.equal(requireOwner(new Headers({'oai-authenticated-user-id':'synthetic-A','oai-authenticated-user-email':'different@example.test'})),'synthetic-A'));
(async()=>{
 const req=new Request('https://ariadne.example.test/mcp',{method:'POST',headers:{'Origin':'https://other.example.test','Content-Type':'text/plain'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name:'list_actions',arguments:{}}})});
 const body=await req.json();
 test('Request.json parses text/plain JSON despite foreign Origin',()=>assert.equal(body.method,'tools/call'));
 const report={commit:'f8142c6490314fc3723d97bac62a1323d6aa7570',source_blob_sha:blobSha,scope:'Isolated auth module and Request parsing; no Sites proxy, cookies, live account or end-to-end CSRF test',tests:results};
 fs.writeFileSync(require('node:path').join(__dirname,'auth-results.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
