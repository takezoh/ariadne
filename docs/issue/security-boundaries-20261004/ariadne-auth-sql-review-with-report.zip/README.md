# Ariadne: authentication and SQL review reproductions

Reviewed commit: `f8142c6490314fc3723d97bac62a1323d6aa7570` (takezoh/ariadne, main observed 2026-10-04).

## Scope

These are isolated local reproductions. They do not call a deployed Site, access a real account, mutate the GitHub repository, or execute the complete Ariadne test suite.

- `reproduce_auth.cjs`: executes the exact `lib/server/auth.ts` source after checking its Git blob SHA. The imported `fail` helper is reproduced locally. Also checks the behavior of the standard `Request.json()` method for a text/plain request. It does NOT establish end-to-end CSRF exploitability or verify Sites proxy authentication.
- `reproduce_sql.py`: exercises SQL statement shapes from `lib/adapters/d1-action-store.ts`, the exact revision guard from migration 0012, and a synthetic schema matching the tested columns/keys. It does NOT execute the full application service. Uses Python SQLite's string/row length limit of 2,000,000 bytes to model the published D1 limit.
- `auth-results.json` and `sql-results.json`: actual local results. A passing assertion can demonstrate an undesirable behavior, such as an oversized generated delta; it is not a claim that the application is vulnerability-free.

## Findings supported

1. The application MCP route lacks the Origin and Content-Type checks present in the Web API route. Whether a cross-origin request can actually mutate deployed data depends on the Sites authentication boundary, cookie behavior, and valid operation/revision values. No live exploit was attempted.
2. The application limits canonical input to 262,144 bytes but does not bound the generated receipt row/delta. A parent plus six children, each child holding 65,536 Japanese characters, produces a 2,363,848-byte full before/after delta on completion. The completion input itself is 198 bytes. An equivalent SQLite length limit rejects the receipt, without partial task updates.

## Run

```sh
# Python 3.11+ (sqlite3.setlimit)
python reproduce_sql.py

# Node with TypeScript installed/resolvable
node reproduce_auth.cjs
```

The scripts write their result JSON files alongside themselves.

## Primary code references

- `lib/server/auth.ts`
- `app/mcp/route.ts`
- `app/api/actions/route.ts`
- `lib/application/action-service.ts`
- `lib/adapters/d1-action-store.ts`
- `lib/domain/operations.ts`
- `drizzle/0012_generic_revision_guard.sql`

No repository commit, deployment, or live database operation was performed by this review.
